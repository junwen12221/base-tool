#!/bin/sh

sh ./runclass.sh com.alibaba.rocketmq.example.operation.Producer $@
