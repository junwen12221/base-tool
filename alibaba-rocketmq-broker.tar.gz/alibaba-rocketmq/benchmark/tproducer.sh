#!/bin/sh

sh ./runclass.sh com.alibaba.rocketmq.example.benchmark.TransactionProducer  $@
